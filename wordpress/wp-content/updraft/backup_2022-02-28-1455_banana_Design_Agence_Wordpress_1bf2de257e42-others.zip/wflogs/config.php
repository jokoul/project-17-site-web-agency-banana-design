<?php exit('Access denied'); __halt_compiler(); ?>
******************************************************************
This file is used by the Wordfence Web Application Firewall. Read 
more at https://docs.wordfence.com/en/Web_Application_Firewall_FAQ
******************************************************************
a:7:{s:9:"wafStatus";s:13:"learning-mode";s:30:"learningModeGracePeriodEnabled";i:1;s:23:"learningModeGracePeriod";i:1646437159;s:7:"authKey";s:64:"?A#[oEy|C>O!h4p0&L)!o95&Tb2;g<YZ4TgoVK/O%Zu^ZSOcM{*z9{Q(}fZ*v/[0";s:7:"version";s:5:"1.0.4";s:11:"wafDisabled";b:0;s:13:"attackDataKey";i:390;}